package com.wallkit.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.SystemClock
import androidx.annotation.RequiresApi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

val EASES: Map<String, (Float) -> Float> = mapOf(
    "smooth" to { u -> 1f - (1f - u).pow(3) },
    "back" to { u -> val c = 1.70158f; 1f + (c + 1f) * (u - 1f).pow(3) + c * (u - 1f).pow(2) },
    "expo" to { u -> if (u >= 1f) 1f else 1f - 2f.pow(-10f * u) },
    "linear" to { u -> u }
)

/** Phone tilt, re-centred slowly so it follows how the phone is held. */
class Tilt(ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    var x = 0f
        private set
    var y = 0f
        private set
    private var bx = Float.NaN
    private var by = 0f

    fun start() {
        val s = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() = sm.unregisterListener(this)

    override fun onSensorChanged(e: SensorEvent) {
        val gx = e.values[0]
        val gy = e.values[1]
        if (bx.isNaN()) { bx = gx; by = gy }
        bx += (gx - bx) * 0.01f
        by += (gy - by) * 0.01f
        x = (-(gx - bx) / 3f).coerceIn(-1f, 1f)
        y = ((gy - by) / 3f).coerceIn(-1f, 1f)
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
}

/**
 * Draws the whole scene: home layers underneath, lock layers on top with the per-layer
 * unlock effect, then particles. prog 0 = locked look, 1 = unlocked look.
 * Used by both the live wallpaper and the custom lock screen so they match exactly.
 */
class SceneRenderer {
    var cfg: Config? = null
        set(v) {
            field = v
            nodes.clear()
            if (v != null) particles.setup(v.particle, v.density, v.accent)
        }
    var prog = 1f
    var tgtX = 0f
    var tgtY = 0f
    var pageOffset = 0.5f
    val particles = Particles()

    private var curX = 0f
    private var curY = 0f
    private var w = 0
    private var h = 0
    private var animating = false
    private var aFrom = 0f
    private var aTo = 0f
    private var aStart = 0L
    private var aDur = 700f
    private var aDone: (() -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint()
    private val bgPaint = Paint()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private val nodes = HashMap<Layer, Any>()

    val isAnimating get() = animating

    fun setSize(nw: Int, nh: Int) {
        if (nw == w && nh == h) return
        w = nw; h = nh
        particles.resize(w.toFloat(), h.toFloat())
    }

    fun animTo(t: Float, done: (() -> Unit)? = null) {
        val dist = abs(t - prog)
        if (dist < 0.001f) { prog = t; animating = false; aDone = null; done?.invoke(); return }
        aFrom = prog; aTo = t
        aStart = SystemClock.uptimeMillis()
        aDur = max(120f, (cfg?.dur ?: 700f) * dist)
        aDone = done
        animating = true
    }

    fun cancelAnim() { animating = false; aDone = null }

    fun burst(x: Float, y: Float) { if (cfg?.touchFx == true) particles.burst(x, y) }

    fun update(dt: Float) {
        if (animating) {
            val u = ((SystemClock.uptimeMillis() - aStart) / aDur).coerceIn(0f, 1f)
            val e = EASES[cfg?.ease ?: "smooth"] ?: EASES.getValue("smooth")
            prog = aFrom + (aTo - aFrom) * e(u)
            if (u >= 1f) {
                prog = aTo; animating = false
                val d = aDone; aDone = null; d?.invoke()
            }
        }
        val a = min(1f, dt * 6f)
        curX += (tgtX - curX) * a
        curY += (tgtY - curY) * a
    }

    fun render(cv: Canvas, dt: Float) {
        cv.drawColor(Color.BLACK)
        val c = cfg
        if (c == null || w == 0) { drawEmpty(cv); return }
        val css = w / 390f
        val k = 16f * c.parallax * css
        val p = prog
        val pc = p.coerceIn(0f, 1f)
        val page = (pageOffset - 0.5f) * w * 0.06f * c.parallax
        val fs = c.fadeStart
        val lockAlpha = if (fs >= 1f) (if (pc >= 0.999f) 0f else 1f) else 1f - ((pc - fs) / (1f - fs)).coerceIn(0f, 1f)

        if (pc > 0.0001f || lockAlpha < 0.999f || c.lock.isEmpty()) {
            cv.save()
            val hs = 1.18f - 0.14f * pc
            cv.scale(hs, hs, w / 2f, h / 2f)
            for (L in c.home) drawLayer(cv, L, c.fx[L.role], false, p, k, page, 1f, css)
            cv.restore()
            if (c.homeDim > 0.001f) {
                dimPaint.color = Color.argb((c.homeDim * pc * 255).toInt().coerceIn(0, 255), 0, 0, 0)
                cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), dimPaint)
            }
        }
        if (lockAlpha > 0.004f) for (L in c.lock) drawLayer(cv, L, c.fx[L.role], true, p, k, 0f, lockAlpha, css)
        particles.step(cv, dt, -curX * k * 1.3f, -curY * k * 1.3f)
    }

    private fun drawLayer(cv: Canvas, L: Layer, f: LayerFx?, lock: Boolean, p: Float, k: Float, page: Float, baseAlpha: Float, css: Float) {
        if (L.bmp.isRecycled) return
        val fx = f ?: DEFAULT_FX
        val lw = w * 1.2f; val lh = h * 1.2f
        val left = -0.1f * w; val top = -0.1f * h
        val bw = L.bmp.width.toFloat(); val bh = L.bmp.height.toFloat()
        val s = max(lw / bw, lh / bh)
        val dw = bw * s; val dh = bh * s
        rect.set(left + (lw - dw) / 2f, top + (lh - dh) / 2f, left + (lw + dw) / 2f, top + (lh + dh) / 2f)

        val d = L.d * fx.tilt
        var tx = -curX * d * k - page * L.d
        var ty = -curY * d * k
        var alpha = baseAlpha
        var rot = 0f; var sc = 1f; var ox = 0f; var oy = 0f; var blur = 0f; var lpc = 0f
        if (lock) {
            val lp = max(0f, (p - fx.delay) / (1f - fx.delay))
            lpc = lp.coerceIn(0f, 1f)
            tx += fx.x / 100f * w * lp
            ty += fx.y / 100f * h * lp
            when (fx.origin) {
                "bl" -> { ox = -0.1f * w; oy = 1.1f * h }
                "br" -> { ox = 1.1f * w; oy = 1.1f * h }
                "t" -> { ox = 0.5f * w; oy = -0.1f * h }
                else -> { ox = 0.5f * w; oy = 0.5f * h }
            }
            rot = fx.rot * lp
            sc = max(0.05f, 1f + (fx.scale - 1f) * lp)
            alpha *= (1f - (1f - fx.fade) * lp).coerceIn(0f, 1f)
            blur = fx.blur * css * lpc
        }
        if (alpha <= 0.004f) return
        val al = (alpha * 255).toInt()

        if (blur > 0.5f) {
            if (Build.VERSION.SDK_INT >= 31 && cv.isHardwareAccelerated) {
                drawBlurred(cv, L, blur, alpha, tx, ty, lock, rot, sc, ox, oy)
                return
            }
            val b = L.blurred
            if (b != null && !b.isRecycled) {
                drawBmp(cv, b, al, tx, ty, lock, rot, sc, ox, oy)
                drawBmp(cv, L.bmp, (al * (1f - lpc)).toInt(), tx, ty, lock, rot, sc, ox, oy)
                return
            }
        }
        drawBmp(cv, L.bmp, al, tx, ty, lock, rot, sc, ox, oy)
    }

    private fun drawBmp(c: Canvas, bmp: Bitmap, al: Int, tx: Float, ty: Float, lock: Boolean, rot: Float, sc: Float, ox: Float, oy: Float) {
        if (al <= 0) return
        c.save()
        c.translate(tx, ty)
        if (lock) {
            c.rotate(rot, ox, oy)
            c.scale(sc, sc, ox, oy)
        }
        paint.alpha = al.coerceIn(0, 255)
        c.drawBitmap(bmp, null, rect, paint)
        c.restore()
    }

    @RequiresApi(31)
    private fun drawBlurred(cv: Canvas, L: Layer, blur: Float, alpha: Float, tx: Float, ty: Float, lock: Boolean, rot: Float, sc: Float, ox: Float, oy: Float) {
        val node = nodes.getOrPut(L) { RenderNode("wk") } as RenderNode
        node.setPosition(0, 0, w, h)
        val rc = node.beginRecording(w, h)
        drawBmp(rc, L.bmp, 255, tx, ty, lock, rot, sc, ox, oy)
        node.endRecording()
        node.setRenderEffect(RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.DECAL))
        node.setAlpha(alpha)
        cv.drawRenderNode(node)
    }

    private fun drawEmpty(cv: Canvas) {
        if (w == 0) return
        bgPaint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF070A1F.toInt(), 0xFF1E1650.toInt(), 0xFF4A2A7A.toInt()), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
        textPaint.textSize = w / 22f
        cv.drawText("WallKit 앱에서 꾸민 뒤", w / 2f, h * 0.46f, textPaint)
        cv.drawText("‘폰에 적용’을 눌러 주세요", w / 2f, h * 0.46f + textPaint.textSize * 1.6f, textPaint)
    }
}
