package com.wallkit.app

import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

private const val BASE_URL = "https://appassets.androidplatform.net/assets/wallkit.html"

/** Shared WebView host for the editor (MainActivity) and the home screen (HomeActivity). */
abstract class WebHostActivity : ComponentActivity() {
    protected lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSave: String? = null
    protected abstract val startUrl: String
    protected open val transparent = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileCallback
        fileCallback = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val data = pendingSave
        pendingSave = null
        if (uri != null && data != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray()) }
                toast("템플릿 파일을 저장했어요")
            } catch (e: Exception) {
                toast("파일을 저장하지 못했어요")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(if (transparent) Color.TRANSPARENT else Color.BLACK)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val wantsImage = params.acceptTypes.joinToString(",").contains("image")
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(if (wantsImage) "image/*" else "*/*")
                return try {
                    pickFile.launch(Intent.createChooser(intent, null)); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }
        web.addJavascriptInterface(WebBridge(this), "Android")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.__back&&window.__back())?'1':'0'") { r ->
                    if (r?.contains("1") != true) onUnhandledBack(this)
                }
            }
        })
        if (savedInstanceState == null) web.loadUrl(startUrl) else web.restoreState(savedInstanceState)
    }

    protected open fun onUnhandledBack(cb: OnBackPressedCallback) {
        cb.isEnabled = false
        onBackPressedDispatcher.onBackPressed()
        cb.isEnabled = true
    }

    override fun onResume() {
        super.onResume()
        LockPrefs.sync(this)
        js("window.__resume&&window.__resume();window.__lockState&&window.__lockState()")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    fun js(code: String) = runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    fun saveFile(name: String, text: String) = runOnUiThread {
        pendingSave = text
        createDoc.launch(name)
    }

    fun applyWallpaper() {
        val info = WallpaperManager.getInstance(this).wallpaperInfo
        if (info != null && info.packageName == packageName) { toast("배경화면을 바꿨어요"); return }
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, WallkitWallpaperService::class.java)
                )
            )
            toast("미리보기에서 ‘배경화면 설정’을 눌러 주세요. 잠금 화면에도 적용을 고르세요")
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                toast("목록에서 WallKit을 골라 주세요")
            } catch (e2: Exception) {
                toast("이 기기는 움직이는 배경화면을 지원하지 않아요")
            }
        }
    }

    fun tapWallpaper(x: Int, y: Int) {
        val loc = IntArray(2)
        web.getLocationOnScreen(loc)
        try {
            WallpaperManager.getInstance(this).sendWallpaperCommand(web.windowToken, WallpaperManager.COMMAND_TAP, loc[0] + x, loc[1] + y, 0, null)
        } catch (_: Exception) {}
    }

    fun setWallOffset(f: Float) {
        try { WallpaperManager.getInstance(this).setWallpaperOffsets(web.windowToken, f.coerceIn(0f, 1f), 0.5f) } catch (_: Exception) {}
    }
}

class MainActivity : WebHostActivity() {
    override val startUrl = BASE_URL
}

/** WallKit as the phone's home app: real installed apps, custom icons, live wallpaper behind. */
class HomeActivity : WebHostActivity() {
    override val startUrl = "$BASE_URL?mode=launcher"
    override val transparent = true
    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            WebBridge.clearIcons()
            js("window.__appsChanged&&window.__appsChanged()")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgRx, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgRx) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        js("window.__home&&window.__home()")
    }

    // A home screen never closes itself on back.
    override fun onUnhandledBack(cb: OnBackPressedCallback) {}
}

class WebBridge(private val act: WebHostActivity) {
    private val pm: PackageManager get() = act.packageManager

    @JavascriptInterface fun begin() = WallStore.begin(act)
    @JavascriptInterface fun putImage(name: String, dataUrl: String) = WallStore.putImage(act, name, dataUrl)
    @JavascriptInterface fun commit(json: String) {
        WallStore.commit(act, json)
        act.runOnUiThread { act.applyWallpaper() }
    }
    @JavascriptInterface fun saveFile(name: String, text: String) = act.saveFile(name, text)

    @JavascriptInterface fun getApps(): String {
        val arr = JSONArray()
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (r in pm.queryIntentActivities(i, 0)) {
            val ai = r.activityInfo
            arr.put(JSONObject().put("key", "${ai.packageName}/${ai.name}").put("label", r.loadLabel(pm).toString()))
        }
        return arr.toString()
    }

    @JavascriptInterface fun getIcon(key: String): String {
        synchronized(cache) { cache[key]?.let { return it } }
        val cn = ComponentName.unflattenFromString(key) ?: return ""
        return try {
            val s = toDataUrl(pm.getActivityIcon(cn), 144)
            synchronized(cache) { cache[key] = s }
            s
        } catch (e: Exception) { "" }
    }

    @JavascriptInterface fun getDefaultDock(): String {
        val arr = JSONArray()
        val seen = HashSet<String>()
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (it in intents) {
            val pkg = pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName ?: continue
            if (pkg == "android") continue
            val cn = pm.getLaunchIntentForPackage(pkg)?.component ?: continue
            val key = "${cn.packageName}/${cn.className}"
            if (seen.add(key)) arr.put(key)
        }
        return arr.toString()
    }

    @JavascriptInterface fun launch(key: String) {
        val cn = ComponentName.unflattenFromString(key) ?: return
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                )
            } catch (e: Exception) { act.toast("앱을 열 수 없어요") }
        }
    }

    @JavascriptInterface fun appInfo(key: String) {
        val pkg = key.substringBefore('/')
        act.runOnUiThread {
            try { act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) } catch (_: Exception) {}
        }
    }

    @JavascriptInterface fun tapWallpaper(x: Int, y: Int) = act.runOnUiThread { act.tapWallpaper(x, y) }
    @JavascriptInterface fun setOffset(f: Float) = act.runOnUiThread { act.setWallOffset(f) }

    @JavascriptInterface fun setLockEnabled(on: Boolean): Boolean {
        LockPrefs.setWanted(act, on)
        if (on && !Settings.canDrawOverlays(act)) act.runOnUiThread {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${act.packageName}")))
                act.toast("WallKit을 찾아 ‘다른 앱 위에 표시’를 켜 주세요")
            } catch (_: Exception) {}
        }
        return LockPrefs.isOn(act)
    }

    @JavascriptInterface fun isLockEnabled(): Boolean = LockPrefs.isOn(act)

    @JavascriptInterface fun openHomeSettings() = act.runOnUiThread {
        try { act.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        catch (_: Exception) { act.toast("설정 → 애플리케이션 → 기본 앱 → 홈 앱에서 WallKit을 골라 주세요") }
    }

    companion object {
        private val cache = HashMap<String, String>()
        fun clearIcons() = synchronized(cache) { cache.clear() }

        /** Draws adaptive icons without the system mask so WallKit can give them its own shape. */
        fun toDataUrl(d: Drawable, size: Int): String {
            val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            if (d is AdaptiveIconDrawable) {
                val o = size / 4
                d.background?.apply { setBounds(-o, -o, size + o, size + o); draw(c) }
                d.foreground?.apply { setBounds(-o, -o, size + o, size + o); draw(c) }
            } else {
                d.setBounds(0, 0, size, size)
                d.draw(c)
            }
            val out = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.PNG, 100, out)
            b.recycle()
            return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }
    }
}
