package com.wallkit.app

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.view.WindowCompat
import java.util.Calendar
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class LockActivity : ComponentActivity() {
    private lateinit var view: LockView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        view = LockView(this) { dismiss() }
        setContentView(view)
        onBackPressedDispatcher.addCallback(this) { /* the lock screen stays until swiped */ }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        view.reset()
    }

    private fun dismiss() {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) { finishQuiet(); return }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() = finishQuiet()
            override fun onDismissError() = finishQuiet()
            override fun onDismissCancelled() = view.relock()
        })
    }

    private fun finishQuiet() {
        finish()
        overridePendingTransition(0, 0)
    }
}

/** Full-screen lock: the layers follow the finger, then fly apart exactly like the editor preview. */
class LockView(ctx: Context, private val onUnlocked: () -> Unit) : View(ctx) {
    private val r = SceneRenderer()
    private val tilt = Tilt(ctx)
    private var lastNs = 0L
    private var x0 = 0f
    private var y0 = 0f
    private var p0 = 0f
    private var vt: VelocityTracker? = null
    private var dismissing = false
    private var loadedVer = Long.MIN_VALUE

    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val clockFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val clockStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; style = Paint.Style.STROKE }
    private val msgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val chevPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val chev = Path()

    init {
        isClickable = true
        r.prog = 0f
    }

    fun reset() {
        r.cancelAnim()
        r.prog = 0f
        dismissing = false
        load()
        invalidate()
    }

    fun relock() {
        dismissing = false
        r.animTo(0f)
    }

    private fun load() {
        val v = WallStore.currentVersion(context.applicationContext)
        if (v == loadedVer) return
        loadedVer = v
        val maxW = max(720, (resources.displayMetrics.widthPixels * 1.25f).toInt())
        Thread {
            val c = ConfigLoader.load(context.applicationContext, maxW)
            post {
                val old = r.cfg
                r.cfg = c
                old?.recycle()
                invalidate()
            }
        }.start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        tilt.start()
        load()
    }

    override fun onDetachedFromWindow() {
        tilt.stop()
        r.cfg?.recycle()
        r.cfg = null
        loadedVer = Long.MIN_VALUE
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        r.setSize(w, h)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.05f, (now - lastNs) / 1e9f)
        lastNs = now
        r.tgtX = tilt.x
        r.tgtY = tilt.y
        r.update(dt)
        r.render(c, dt)
        drawOverlay(c)
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (dismissing) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                r.cancelAnim()
                x0 = e.x; y0 = e.y; p0 = r.prog
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                r.prog = (p0 + (y0 - e.y) / (height * 0.5f)).coerceIn(0f, 1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                vt?.recycle(); vt = null
                val moved = hypot(e.x - x0, e.y - y0)
                if (e.actionMasked == MotionEvent.ACTION_UP && (r.prog > 0.35f || vy < -1500f)) {
                    dismissing = true
                    r.animTo(1f) { onUnlocked() }
                } else {
                    r.animTo(0f)
                    if (e.actionMasked == MotionEvent.ACTION_UP && moved < 20f) r.burst(e.x, e.y)
                }
            }
        }
        return true
    }

    private fun drawOverlay(c: Canvas) {
        val cfg = r.cfg
        val pc = r.prog.coerceIn(0f, 1f)
        val a = (1f - pc * 1.8f).coerceIn(0f, 1f)
        if (a <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val css = w / 390f
        val style = cfg?.clockStyle ?: "glass"
        val cal = Calendar.getInstance()
        var hr = cal.get(Calendar.HOUR_OF_DAY)
        val h24 = cfg?.h24 ?: true
        if (!h24) hr = if (hr % 12 == 0) 12 else hr % 12
        val time = (if (h24) "%02d" else "%d").format(hr) + ":" + "%02d".format(cal.get(Calendar.MINUTE))
        val date = "${cal.get(Calendar.MONTH) + 1}월 ${cal.get(Calendar.DAY_OF_MONTH)}일 ${"일월화수목금토"[cal.get(Calendar.DAY_OF_WEEK) - 1]}요일"

        c.save()
        c.translate(0f, -pc * 0.35f * h)
        var y = 86f * css
        if (cfg?.showDate != false) {
            datePaint.textSize = 17f * css
            datePaint.setShadowLayer(9f * css, 0f, 1f * css, 0x38000000)
            datePaint.alpha = (a * 235).toInt()
            c.drawText(date, w / 2f, y, datePaint)
        }
        val size = (if (style == "glass") 118f else 100f) * css
        y += size * 0.95f
        clockFill.textSize = size; clockStroke.textSize = size
        when (style) {
            "thin" -> { clockFill.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL); clockFill.color = Color.WHITE; clockFill.alpha = (a * 255).toInt(); c.drawText(time, w / 2f, y, clockFill) }
            "bold" -> { clockFill.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); clockFill.color = Color.WHITE; clockFill.alpha = (a * 255).toInt(); c.drawText(time, w / 2f, y, clockFill) }
            "outline" -> { clockStroke.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); clockStroke.strokeWidth = 1.6f * css; clockStroke.color = Color.WHITE; clockStroke.alpha = (a * 255).toInt(); c.drawText(time, w / 2f, y, clockStroke) }
            else -> {
                val tf = Typeface.create("sans-serif-light", Typeface.NORMAL)
                clockFill.typeface = tf; clockStroke.typeface = tf
                clockFill.color = Color.WHITE; clockFill.alpha = (a * 66).toInt()
                clockStroke.color = Color.WHITE; clockStroke.alpha = (a * 155).toInt(); clockStroke.strokeWidth = 1f * css
                c.drawText(time, w / 2f, y, clockFill); c.drawText(time, w / 2f, y, clockStroke)
            }
        }
        val msg = cfg?.lockMsg ?: ""
        if (msg.isNotBlank()) {
            msgPaint.textSize = 15f * css
            msgPaint.setShadowLayer(9f * css, 0f, 1f * css, 0x38000000)
            msgPaint.alpha = (a * 235).toInt()
            c.drawText(msg, w / 2f, y + 34f * css, msgPaint)
        }
        c.restore()

        // hint + bar at the bottom
        val t = System.currentTimeMillis() / 1000.0
        val bob = (sin(t * Math.PI * 2 / 1.6) * 3.5).toFloat() * css
        val hy = h - 70f * css
        msgPaint.textSize = 13f * css
        msgPaint.alpha = (a * 220).toInt()
        c.drawText("위로 쓸어올려 잠금 해제", w / 2f, hy, msgPaint)
        chev.reset()
        chev.moveTo(w / 2f - 9f * css, hy - 22f * css + bob)
        chev.lineTo(w / 2f, hy - 29f * css + bob)
        chev.lineTo(w / 2f + 9f * css, hy - 22f * css + bob)
        chevPaint.strokeWidth = 2.4f * css
        chevPaint.alpha = (a * 220).toInt()
        c.drawPath(chev, chevPaint)
        barPaint.alpha = (a * 215).toInt()
        c.drawRoundRect(w / 2f - 67f * css, h - 26f * css, w / 2f + 67f * css, h - 21f * css, 3f * css, 3f * css, barPaint)
    }
}
