package com.wallkit.app

import android.app.KeyguardManager
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class WallkitWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = WkEngine()

    inner class WkEngine : Engine() {
        private val ctx: Context get() = this@WallkitWallpaperService
        private val main = Handler(Looper.getMainLooper())
        private val io = Executors.newSingleThreadExecutor()
        private val r = SceneRenderer()
        private val tilt by lazy { Tilt(ctx) }
        private var loadedVer = Long.MIN_VALUE
        private var loading = false
        private var destroyed = false
        private var visible = false
        private var lastNs = 0L
        private var downX = 0f
        private var downY = 0f

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                when (i.action) {
                    // With the WallKit lock screen on, that screen already played the unlock; just show home.
                    Intent.ACTION_USER_PRESENT -> if (LockPrefs.isOn(ctx)) { r.cancelAnim(); r.prog = 1f } else r.animTo(1f)
                    Intent.ACTION_SCREEN_OFF -> { r.cancelAnim(); r.prog = if (LockPrefs.isOn(ctx)) 1f else 0f }
                }
            }
        }

        private val frame = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame()
                main.postDelayed(this, 16)
            }
        }

        private fun keyguardLocked() = (ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            setTouchEventsEnabled(true)
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            r.prog = if (!isPreview && keyguardLocked() && !LockPrefs.isOn(ctx)) 0f else 1f
        }

        override fun onDestroy() {
            super.onDestroy()
            destroyed = true
            visible = false
            main.removeCallbacks(frame)
            try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
            tilt.stop()
            io.shutdownNow()
            r.cfg?.recycle()
            r.cfg = null
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                if (!isPreview && keyguardLocked() && !r.isAnimating && !LockPrefs.isOn(ctx)) r.prog = 0f
                tilt.start()
                lastNs = 0L
                main.removeCallbacks(frame)
                main.post(frame)
            } else {
                tilt.stop()
                main.removeCallbacks(frame)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            r.setSize(width, height)
            loadedVer = Long.MIN_VALUE
            ensureConfig(width)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            main.removeCallbacks(frame)
        }

        override fun onOffsetsChanged(xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPx: Int, yPx: Int) {
            r.pageOffset = xOffset
        }

        override fun onCommand(action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP) r.burst(x.toFloat(), y.toFloat())
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        override fun onTouchEvent(e: MotionEvent) {
            if (!isPreview) return
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y }
                MotionEvent.ACTION_UP -> if (abs(e.x - downX) < 20 && abs(e.y - downY) < 20) {
                    r.burst(e.x, e.y)
                    r.cancelAnim()
                    r.prog = 0f
                    r.animTo(1f)
                }
            }
        }

        private fun ensureConfig(width: Int = surfaceHolder.surfaceFrame.width()) {
            val v = WallStore.currentVersion(ctx.applicationContext)
            if (v == loadedVer || loading || width <= 0) return
            loading = true
            val maxW = max(720, (width * 1.25f).toInt())
            try {
                io.execute {
                    val c = ConfigLoader.load(ctx.applicationContext, maxW)
                    main.post {
                        loading = false
                        if (destroyed) { c?.recycle(); return@post }
                        val old = r.cfg
                        r.cfg = c
                        loadedVer = v
                        old?.recycle()
                    }
                }
            } catch (e: Exception) {
                loading = false
            }
        }

        private fun drawFrame() {
            ensureConfig()
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0.016f else min(0.05f, (now - lastNs) / 1e9f)
            lastNs = now
            r.tgtX = tilt.x
            r.tgtY = tilt.y
            r.update(dt)
            val holder = surfaceHolder
            val canvas: Canvas = try { holder.lockHardwareCanvas() } catch (e: Exception) { null } ?: return
            try {
                r.render(canvas, dt)
            } finally {
                try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }
    }
}
