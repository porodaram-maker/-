package com.wallkit.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import org.json.JSONObject
import java.io.File
import kotlin.math.max

class LayerFx(
    val x: Float, val y: Float, val rot: Float, val scale: Float, val blur: Float,
    val fade: Float, val delay: Float, val origin: String, val tilt: Float
)

val DEFAULT_FX = LayerFx(0f, 0f, 0f, 1f, 0f, 1f, 0f, "c", 1f)

class Layer(val bmp: Bitmap, val d: Float, val role: String) {
    /** Pre-blurred copy, only used on Android 11 and older where live blur is not available. */
    var blurred: Bitmap? = null
}

class Config(
    val parallax: Float, val particle: String, val density: Float, val touchFx: Boolean,
    val accent: Int, val homeDim: Float,
    val dur: Float, val ease: String, val fadeStart: Float,
    val fx: Map<String, LayerFx>,
    val clockStyle: String, val h24: Boolean, val showDate: Boolean, val lockMsg: String,
    val lock: List<Layer>, val home: List<Layer>
) {
    fun recycle() {
        (lock + home).forEach {
            if (!it.bmp.isRecycled) it.bmp.recycle()
            it.blurred?.let { b -> if (!b.isRecycled) b.recycle() }
        }
    }
}

object ConfigLoader {
    fun load(c: Context, maxW: Int): Config? {
        val dir = WallStore.dir(c)
        val f = File(dir, "config.json")
        if (!f.exists()) return null
        return try {
            val j = JSONObject(f.readText())
            val u = j.optJSONObject("ufx") ?: JSONObject()
            val ls = u.optJSONObject("layers") ?: JSONObject()
            val fx = HashMap<String, LayerFx>()
            for (r in listOf("back", "mid", "front")) {
                val o = ls.optJSONObject(r) ?: JSONObject()
                fx[r] = LayerFx(
                    o.optDouble("x", 0.0).toFloat(), o.optDouble("y", 0.0).toFloat(),
                    o.optDouble("rot", 0.0).toFloat(), o.optDouble("scale", 1.0).toFloat(),
                    o.optDouble("blur", 0.0).toFloat(),
                    o.optDouble("fade", 1.0).toFloat(), o.optDouble("delay", 0.0).toFloat().coerceIn(0f, 0.95f),
                    o.optString("origin", "c"), o.optDouble("tilt", 1.0).toFloat()
                )
            }
            fun layers(key: String): List<Layer> {
                val a = j.optJSONArray(key) ?: return emptyList()
                val out = ArrayList<Layer>()
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val name = o.getString("file").replace(Regex("[^a-zA-Z0-9_]"), "_")
                    val bmp = decode(File(dir, name), maxW) ?: continue
                    out.add(Layer(bmp, o.optDouble("d", 1.0).toFloat(), o.optString("role", "back")))
                }
                return out
            }
            val lock = layers("lock")
            if (Build.VERSION.SDK_INT < 31) {
                for (L in lock) {
                    val b = fx[L.role]?.blur ?: 0f
                    if (b > 0.5f) L.blurred = fastBlur(L.bmp, b)
                }
            }
            Config(
                j.optDouble("parallax", 1.0).toFloat(), j.optString("particle", "none"),
                j.optDouble("density", 1.0).toFloat(), j.optBoolean("touchFx", true),
                parseColor(j.optString("accent", "#ffffff")), j.optDouble("homeDim", 0.1).toFloat(),
                u.optDouble("dur", 700.0).toFloat(), u.optString("ease", "smooth"),
                u.optDouble("fadeStart", 0.55).toFloat(), fx,
                j.optString("clockStyle", "glass"), j.optBoolean("h24", true),
                j.optBoolean("showDate", true), j.optString("lockMsg", ""),
                lock, layers("home")
            )
        } catch (e: Throwable) {
            null
        }
    }

    private fun parseColor(s: String) = try { Color.parseColor(s) } catch (e: Exception) { Color.WHITE }

    private fun decode(f: File, maxW: Int): Bitmap? {
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxW) sample *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun fastBlur(src: Bitmap, amount: Float): Bitmap? = try {
        val f = (amount * 0.6f).coerceIn(2f, 24f)
        val sw = max(1, (src.width / f).toInt())
        val sh = max(1, (src.height / f).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val up = Bitmap.createScaledBitmap(small, max(1, src.width / 2), max(1, src.height / 2), true)
        if (small != up) small.recycle()
        up
    } catch (e: Throwable) {
        null
    }
}
