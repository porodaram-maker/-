package com.wallkit.app

import android.content.Context
import android.util.Base64
import java.io.File

/** Saves what the editor sends, then swaps it in all at once so the wallpaper never reads a half-written set. */
object WallStore {
    @Volatile
    var version: Long = -1L

    fun dir(c: Context) = File(c.filesDir, "wp")
    private fun staging(c: Context) = File(c.filesDir, "wp_new")

    fun currentVersion(c: Context): Long {
        if (version < 0) version = c.getSharedPreferences("wk", Context.MODE_PRIVATE).getLong("v", 0L)
        return version
    }

    @Synchronized
    fun begin(c: Context) {
        val s = staging(c)
        s.deleteRecursively()
        s.mkdirs()
    }

    @Synchronized
    fun putImage(c: Context, name: String, dataUrl: String) {
        val safe = name.replace(Regex("[^a-zA-Z0-9_]"), "_")
        val comma = dataUrl.indexOf(',')
        val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
        File(staging(c), safe).writeBytes(bytes)
    }

    @Synchronized
    fun commit(c: Context, json: String) {
        val s = staging(c)
        File(s, "config.json").writeText(json)
        val d = dir(c)
        val old = File(c.filesDir, "wp_old")
        old.deleteRecursively()
        if (d.exists()) d.renameTo(old)
        s.renameTo(d)
        old.deleteRecursively()
        version = System.currentTimeMillis()
        c.getSharedPreferences("wk", Context.MODE_PRIVATE).edit().putLong("v", version).apply()
    }
}
