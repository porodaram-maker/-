package com.wallkit.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

object LockPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("wk", Context.MODE_PRIVATE)
    fun wanted(c: Context) = sp(c).getBoolean("lockWanted", false)
    /** On only when the person asked for it AND Android lets us show it over other apps. */
    fun isOn(c: Context) = wanted(c) && Settings.canDrawOverlays(c)

    fun setWanted(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("lockWanted", on).apply()
        sync(c)
    }

    fun sync(c: Context) {
        val i = Intent(c, LockService::class.java)
        try {
            if (isOn(c)) ContextCompat.startForegroundService(c, i) else c.stopService(i)
        } catch (_: Exception) {}
    }
}

/** Keeps listening for the screen turning off so the WallKit lock screen is ready when it turns back on. */
class LockService : Service() {
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF && LockPrefs.isOn(c)) showLock(c)
        }
    }
    private var registered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg()
        ContextCompat.registerReceiver(this, rx, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (!LockPrefs.isOn(this)) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        if (registered) try { unregisterReceiver(rx) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "WallKit 잠금 화면", NotificationManager.IMPORTANCE_MIN))
        }
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WallKit 잠금 화면이 켜져 있어요")
            .setContentText("앱의 꾸미기 → 잠금 화면에서 끌 수 있어요")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 7, n, type)
    }

    companion object {
        private const val CH = "wk_lock"
        fun showLock(c: Context) {
            try {
                c.startActivity(
                    Intent(c, LockActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                )
            } catch (_: Exception) {}
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) LockPrefs.sync(c)
    }
}
