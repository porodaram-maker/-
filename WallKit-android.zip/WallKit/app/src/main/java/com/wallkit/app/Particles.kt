package com.wallkit.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Same floating effects as the editor: stars, petals, sparks, bubbles, snow, plus the tap burst. */
class Particles {
    private class P {
        var x = 0f; var y = 0f; var z = 1f; var t = 0f; var r = 1f
        var vx = 0f; var vy = 0f; var rot = 0f; var vr = 0f; var sp = 1f
        var hue = false; var life = 1f; var burst = false; var col = Color.WHITE
    }

    private val ps = ArrayList<P>()
    private val rnd = Random()
    private var type = "none"
    private var dens = 1f
    private var accent = Color.WHITE
    private var w = 0f
    private var h = 0f
    private var css = 1f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val oval = RectF()
    private var shootIn = 2f
    private var ssX = 0f; private var ssY = 0f; private var ssL = -1f
    private var ringX = 0f; private var ringY = 0f; private var ringT = -1f

    fun resize(nw: Float, nh: Float) { w = nw; h = nh; css = nw / 390f; seed() }
    fun setup(t: String, d: Float, acc: Int) { type = t; dens = d; accent = acc; seed() }

    private fun f() = rnd.nextFloat()
    private fun base() = when (type) {
        "stars" -> 90; "petals" -> 26; "sparks" -> 55; "bubbles" -> 28; "snow" -> 80; else -> 0
    }

    private fun seed() {
        ps.removeAll { !it.burst }
        if (w <= 0f) return
        repeat((base() * dens).toInt()) { ps.add(make(true)) }
    }

    private fun make(init: Boolean): P {
        val p = P()
        p.x = f() * w; p.y = f() * h; p.z = 0.5f + f(); p.t = f() * 6.28f
        p.rot = f() * 6.28f; p.vr = (f() - 0.5f) * 2f
        when (type) {
            "stars" -> { p.r = f() * 1.4f + 0.4f; p.sp = f() * 2f + 1f }
            "petals" -> { p.r = f() * 4f + 4f; p.vy = f() * 35f + 25f; p.vx = f() * 20f + 5f
                if (!init) { p.y = -10f * css; p.x = f() * w * 1.2f - w * 0.2f } }
            "sparks" -> { p.r = f() * 1.6f + 0.8f; p.vy = -(f() * 40f + 20f); p.vx = (f() - 0.5f) * 10f
                p.hue = f() > 0.5f; if (!init) p.y = h + 10f * css }
            "bubbles" -> { p.r = f() * 5f + 2f; p.vy = -(f() * 30f + 15f); if (!init) p.y = h + 10f * css }
            "snow" -> { p.r = f() * 2.2f + 0.8f; p.vy = f() * 25f + 15f; p.vx = (f() - 0.5f) * 8f
                if (!init) p.y = -5f * css }
        }
        return p
    }

    fun burst(x: Float, y: Float) {
        for (i in 0 until 18) {
            val a = f() * 6.283f
            val s = f() * 160f + 60f
            ps.add(P().apply {
                burst = true; this.x = x; this.y = y; vx = cos(a) * s; vy = sin(a) * s
                r = f() * 2.5f + 1.5f; col = if (i % 3 == 0) Color.WHITE else accent
            })
        }
        ringX = x; ringY = y; ringT = 0f
    }

    fun step(cv: Canvas, dt: Float, ox: Float, oy: Float) {
        val s = css
        var i = ps.size - 1
        while (i >= 0) {
            val p = ps[i]
            if (p.burst) {
                p.x += p.vx * s * dt; p.y += p.vy * s * dt
                p.vx *= 1f - 2.5f * dt; p.vy *= 1f - 2.5f * dt; p.life -= dt * 1.1f
                if (p.life <= 0f) { ps.removeAt(i); i--; continue }
                paint.color = p.col; paint.alpha = (p.life * 255).toInt()
                cv.drawCircle(p.x, p.y, p.r * s * (0.5f + p.life), paint)
                paint.alpha = (p.life * 0.22f * 255).toInt()
                cv.drawCircle(p.x, p.y, p.r * s * 4f, paint)
                i--; continue
            }
            p.t += dt
            val X = p.x + ox * p.z
            val Y = p.y + oy * p.z
            when (type) {
                "stars" -> {
                    paint.color = Color.WHITE
                    paint.alpha = ((0.25f + 0.75f * abs(sin(p.t * p.sp * 0.5f))) * 255).toInt()
                    cv.drawCircle(X, Y, p.r * s, paint)
                }
                "petals" -> {
                    p.x += (p.vx + sin(p.t * 1.5f) * 25f) * s * dt; p.y += p.vy * s * dt; p.rot += p.vr * dt
                    val r = p.r * s
                    cv.save(); cv.translate(X, Y); cv.rotate(Math.toDegrees(p.rot.toDouble()).toFloat())
                    cv.scale(1f, abs(sin(p.t * 2f)) * 0.5f + 0.5f)
                    paint.color = 0xFFFFB8CF.toInt(); paint.alpha = 230
                    oval.set(-r, -r * 0.62f, r, r * 0.62f); cv.drawOval(oval, paint)
                    paint.color = 0xFFFF8FB3.toInt(); paint.alpha = 230
                    oval.set(r * 0.05f, -r * 0.2f, r * 0.65f, r * 0.2f); cv.drawOval(oval, paint)
                    cv.restore()
                }
                "sparks" -> {
                    p.x += (p.vx + sin(p.t * 2f) * 8f) * s * dt; p.y += p.vy * s * dt
                    paint.color = if (p.hue) 0xFF00E5FF.toInt() else 0xFFFF4FD8.toInt()
                    paint.alpha = ((0.08f + 0.18f * (0.5f + 0.5f * sin(p.t * 8f))) * 255).toInt()
                    cv.drawCircle(X, Y, p.r * s * 4f, paint)
                    paint.alpha = 230; cv.drawCircle(X, Y, p.r * s, paint)
                }
                "bubbles" -> {
                    p.x += sin(p.t * 2f + p.z * 5f) * 14f * s * dt; p.y += p.vy * s * dt
                    stroke.color = 0xFFDFFCFF.toInt(); stroke.alpha = 140; stroke.strokeWidth = s
                    cv.drawCircle(X, Y, p.r * s, stroke)
                    paint.color = Color.WHITE; paint.alpha = 180
                    cv.drawCircle(X - p.r * s * 0.35f, Y - p.r * s * 0.35f, p.r * s * 0.25f, paint)
                }
                "snow" -> {
                    p.x += (p.vx + sin(p.t + p.z * 3f) * 10f) * s * dt; p.y += p.vy * p.z * s * dt
                    paint.color = Color.WHITE; paint.alpha = 215
                    cv.drawCircle(X, Y, p.r * p.z * s, paint)
                }
            }
            if (type != "stars" && (p.y < -20f * s || p.y > h + 20f * s || p.x < -40f * s || p.x > w + 40f * s)) ps[i] = make(false)
            i--
        }

        if (type == "stars") {
            shootIn -= dt
            if (shootIn <= 0f && ssL < 0f) { ssX = f() * w * 0.6f + w * 0.35f; ssY = f() * h * 0.3f; ssL = 0f; shootIn = 3f + f() * 4f }
            if (ssL >= 0f) {
                ssL += dt
                val k = ssL * 420f * s
                val x = ssX - k; val y = ssY + k * 0.45f
                stroke.color = Color.WHITE
                stroke.shader = LinearGradient(x, y, x + 90f * s, y - 40f * s, Color.WHITE, Color.TRANSPARENT, Shader.TileMode.CLAMP)
                stroke.strokeWidth = 1.6f * s
                stroke.alpha = ((1f - ssL * 1.4f).coerceIn(0f, 1f) * 255).toInt()
                cv.drawLine(x, y, x + 90f * s, y - 40f * s, stroke)
                stroke.shader = null
                if (ssL > 0.8f) ssL = -1f
            }
        }
        if (ringT >= 0f) {
            ringT += dt
            stroke.color = accent; stroke.strokeWidth = 2f * s
            stroke.alpha = ((0.9f - ringT * 1.4f).coerceIn(0f, 1f) * 255).toInt()
            cv.drawCircle(ringX, ringY, (18f + ringT * 170f) * s, stroke)
            if (ringT > 0.65f) ringT = -1f
        }
    }
}
